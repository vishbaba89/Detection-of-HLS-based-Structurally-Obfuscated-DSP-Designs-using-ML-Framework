import re
from collections import defaultdict


def main(path):
    # --- Step 1: Load the file ---
    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Parse all component instances ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    # --- Step 3: Build input/output maps for each signal ---
    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            # identify outputs (common naming for output ports)
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 4: Helper to find connections ---
    def find_connection_chain(start_type, mid1_type, mid2_type, end_type):
        """Detect a chain: start_type → mid1_type → mid2_type → end_type"""
        for signal1, (src_type, src_inst) in outputs.items():
            if src_type.startswith(start_type):
                # signal1 output from start_type goes into mid1_type?
                for (dst_type1, dst_inst1) in inputs.get(signal1, []):
                    if dst_type1.startswith(mid1_type):
                        # now, find output from mid1_type
                        for signal2, (src_type2, src_inst2) in outputs.items():
                            if src_inst2 == dst_inst1:  # same instance that produced mid1 output
                                # does that signal go into mid2_type?
                                for (dst_type2, dst_inst2) in inputs.get(signal2, []):
                                    if dst_type2.startswith(mid2_type):
                                        # finally, does mid2 output go to end_type?
                                        for signal3, (src_type3, src_inst3) in outputs.items():
                                            if src_inst3 == dst_inst2:
                                                for (dst_type3, dst_inst3) in inputs.get(signal3, []):
                                                    if dst_type3.startswith(end_type):
                                                        return True
        return False

    # --- Step 5: Check for Adder → Demux → Mux → Adder chain ---
    pattern_found = find_connection_chain("adder", "demux", "mux", "adder")

    # --- Step 6: Report ---
    # if pattern_found:
    #     print("✅ Series_of_back_to_back_interconnectivity_demux_output_of_adder_connected_to_mux_input_of_adder FOUND")
    # else:
    #     print("❌ Pattern NOT FOUND")
    return pattern_found