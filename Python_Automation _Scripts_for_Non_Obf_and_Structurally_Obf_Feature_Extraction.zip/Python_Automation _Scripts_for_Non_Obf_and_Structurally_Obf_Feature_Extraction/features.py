import os
import re
import sys
from collections import defaultdict

# -----------------------------
# Normalization & type helpers
# -----------------------------

def norm_name(s: str) -> str:
    return re.sub(r'[\s_]', '', s.lower())

def comp_type_name(raw_name: str) -> str:
    n = norm_name(raw_name)
    if n.startswith('mux'): return 'mux'
    if n.startswith('demux'): return 'demux'
    if n.startswith('adder') or n == 'add': return 'adder'
    if n.startswith('mul') or n.startswith('multiplier'): return 'mul'
    if n.startswith('sub') or n.startswith('subtract'): return 'sub'
    if n.startswith('latch'): return 'latch'
    if n == 'reg' or n.startswith('register'): return 'reg'
    return n  # fallback (rare)

def is_latch_or_reg(ctype: str) -> bool:
    return ctype in ('latch', 'reg')


# -----------------------------
# Parsing: components & datapath
# -----------------------------

def parse_entities_and_components_from_text(text: str):
    """
    Return a mapping: comp_name -> {port_name: 'in'|'out'}
    Supports both:
      - entity ... port ( ... );
      - component ... is port ( ... ); end component;
    """
    text = text.lower()

    def extract_ports(port_block: str):
        ports = {}
        # split into clauses ending with ';'
        for clause in re.split(r';', port_block):
            clause = clause.strip()
            if not clause:
                continue
            m = re.search(r'^(.*?)\s*:\s*(in|out)\b', clause)
            if not m:
                continue
            names_part = m.group(1)
            direction = m.group(2)
            # support multiple names separated by commas
            for nm in [x.strip() for x in names_part.split(',') if x.strip()]:
                ports[nm] = direction
        return ports

    comps = {}

    # ENTITY blocks
    for m in re.finditer(r'entity\s+(\w+)\s+is\s+.*?port\s*\((.*?)\)\s*;.*?end\s+\1', text, re.S):
        ename, pblock = m.group(1), m.group(2)
        ports = extract_ports(pblock)
        comps[ename] = ports

    # COMPONENT blocks
    for m in re.finditer(r'component\s+(\w+)\s+is\s+.*?port\s*\((.*?)\)\s*;.*?end\s+component', text, re.S):
        cname, pblock = m.group(1), m.group(2)
        ports = extract_ports(pblock)
        # merge/override (component declaration inside datapath)
        if cname in comps:
            comps[cname].update(ports)
        else:
            comps[cname] = ports

    return comps


def parse_instances_from_text(text: str):
    """
    Return list of (inst_name, comp_name, {port:signal})
    Accepts multi-line PORT MAP.
    """
    text = text.lower()
    insts = []
    for m in re.finditer(r'(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\)\s*;', text, re.S):
        inst, comp, body = m.group(1), m.group(2), m.group(3)
        portmap = dict(re.findall(r'(\w+)\s*=>\s*([\w\d_]+)', body))
        insts.append((inst, comp, portmap))
    return insts


def load_component_definitions_from_dir(dir_path: str):
    """
    Scan all .vhd/.vhdl/.txt files in the directory for entity/component port directions.
    """
    comp_ports = {}
    for fn in os.listdir(dir_path):
        if not re.search(r'\.(vhd|vhdl|txt)$', fn, re.I):
            continue
        try:
            with open(os.path.join(dir_path, fn), 'r', encoding='utf-8') as f:
                text = f.read()
            ports = parse_entities_and_components_from_text(text)
            for k, v in ports.items():
                if k in comp_ports:
                    comp_ports[k].update(v)
                else:
                    comp_ports[k] = v
        except Exception:
            pass
    return comp_ports


def build_connectivity(datapath_file: str):
    """
    Build connectivity using:
      - component/entity port directions from all files in same folder (plus the datapath file itself)
      - instances (inst: comp port map) from datapath file
    Returns:
      inst_type: inst -> canonical component type ('mux','demux','adder','mul','sub','latch','reg', or raw)
      signal_src: signal -> (ctype, inst)
      signal_dst: signal -> list of (ctype, inst)
      instances: raw instance tuples
      comp_ports: raw ports map (for inspection if needed)
    """
    dir_path = os.path.dirname(os.path.abspath(datapath_file))
    comp_ports = load_component_definitions_from_dir(dir_path)

    # Also parse component declarations embedded in the datapath file
    with open(datapath_file, 'r', encoding='utf-8') as f:
        dtext = f.read()
    inline = parse_entities_and_components_from_text(dtext)
    for k, v in inline.items():
        if k in comp_ports: comp_ports[k].update(v)
        else: comp_ports[k] = v

    # Build instance list from datapath
    instances = parse_instances_from_text(dtext)

    # Build direction-aware connectivity
    inst_type = {}
    signal_src = {}
    signal_dst = defaultdict(list)

    # Create name-normalized map for component lookups
    comp_by_norm = {}
    for cname in comp_ports.keys():
        comp_by_norm[norm_name(cname)] = cname

    for inst, comp, pmap in instances:
        # try exact, else normalized match
        comp_key = comp
        if comp_key not in comp_ports:
            nkey = comp_by_norm.get(norm_name(comp), None)
            if nkey:
                comp_key = nkey

        ports = comp_ports.get(comp_key, {})
        ctype = comp_type_name(comp_key)
        inst_type[inst] = ctype

        for p, sig in pmap.items():
            direction = ports.get(p, None)
            if direction == 'out':
                signal_src[sig] = (ctype, inst)
            elif direction == 'in':
                signal_dst[sig].append((ctype, inst))
            else:
                # Unknown port direction: ignore
                pass

    return inst_type, signal_src, signal_dst, instances, comp_ports


# -----------------------------
# Path utilities (latch/reg transparent)
# -----------------------------

def find_path_to_types(start_signal: str,
                       signal_src,
                       signal_dst,
                       target_prefixes,
                       depth=0,
                       visited_sig=None):
    """
    From a signal, see if it reaches a component whose type starts with any of target_prefixes.
    We allow passing through latch/reg: signal -> (latch/reg) -> its output signal(s) -> ...
    Returns (ctype, inst) or None.
    """
    if visited_sig is None:
        visited_sig = set()
    if depth > 50 or start_signal in visited_sig:
        return None
    visited_sig.add(start_signal)

    # consumers of start_signal
    for (ctype, inst) in signal_dst.get(start_signal, []):
        # target?
        if any(ctype.startswith(tp) for tp in target_prefixes):
            return (ctype, inst)
        # pass-through?
        if is_latch_or_reg(ctype):
            # follow outputs of that latch/reg instance
            outs = [s for s, (c, i) in signal_src.items() if i == inst]
            for o in outs:
                r = find_path_to_types(o, signal_src, signal_dst, target_prefixes,
                                       depth+1, visited_sig)
                if r:
                    return r
    return None


def instance_output_signals(inst: str, signal_src):
    return [s for s, (c, i) in signal_src.items() if i == inst]


def instance_input_signals(inst: str, signal_dst):
    return [sig for sig, sinks in signal_dst.items() if any(i == inst for (_c, i) in sinks)]


# -----------------------------
# Features (i) to (vii)
# -----------------------------

# (i) Adder output → Demux → Mux → Adder (allow latches/regs between)
def feature_1(signal_src, signal_dst, inst_type):
    for sig, (ctype, inst) in signal_src.items():
        if ctype != 'adder': 
            continue
        # adder out -> demux
        d = find_path_to_types(sig, signal_src, signal_dst, ['demux'])
        if not d: 
            continue
        d_inst = d[1]
        # demux outputs
        for so in instance_output_signals(d_inst, signal_src):
            # demux out -> mux
            m = find_path_to_types(so, signal_src, signal_dst, ['mux'])
            if not m: 
                continue
            m_inst = m[1]
            # mux out -> adder
            for mo in instance_output_signals(m_inst, signal_src):
                a = find_path_to_types(mo, signal_src, signal_dst, ['adder'])
                if a:
                    return True
    return False


# (ii) Two demux outputs of adder → mux → adder (count demux outputs that reach)
def feature_2(signal_src, signal_dst, inst_type):
    for sig, (ctype, inst) in signal_src.items():
        if ctype != 'adder': 
            continue
        d = find_path_to_types(sig, signal_src, signal_dst, ['demux'])
        if not d:
            continue
        d_inst = d[1]
        hits = 0
        for so in instance_output_signals(d_inst, signal_src):
            m = find_path_to_types(so, signal_src, signal_dst, ['mux'])
            if not m:
                continue
            m_inst = m[1]
            if any(find_path_to_types(mo, signal_src, signal_dst, ['adder'])
                   for mo in instance_output_signals(m_inst, signal_src)):
                hits += 1
        if hits >= 2:
            return True
    return False


# (iii) Two demux outputs from same FU (adder/mul) → mux inputs → (one) adder
def feature_3(signal_src, signal_dst, inst_type):
    for sig, (ctype, inst) in signal_src.items():
        if ctype not in ('adder', 'mul'):
            continue
        d = find_path_to_types(sig, signal_src, signal_dst, ['demux'])
        if not d:
            continue
        d_inst = d[1]
        hits = 0
        for so in instance_output_signals(d_inst, signal_src):
            m = find_path_to_types(so, signal_src, signal_dst, ['mux'])
            if not m:
                continue
            m_inst = m[1]
            if any(find_path_to_types(mo, signal_src, signal_dst, ['adder'])
                   for mo in instance_output_signals(m_inst, signal_src)):
                hits += 1
        if hits >= 2:
            return True
    return False


# (iv) Demux(adder) → mux(adder) + register input to that mux
def feature_4(signal_src, signal_dst, inst_type):
    # Find a mux that both:
    #  - is fed (via demux outputs) by an adder output
    #  - also has at least one input driven by reg/latch
    for sig, (ctype, inst) in signal_src.items():
        if ctype != 'adder':
            continue
        d = find_path_to_types(sig, signal_src, signal_dst, ['demux'])
        if not d: 
            continue
        d_inst = d[1]
        for so in instance_output_signals(d_inst, signal_src):
            m = find_path_to_types(so, signal_src, signal_dst, ['mux'])
            if not m:
                continue
            m_inst = m[1]
            # inputs of this mux
            mux_inputs = instance_input_signals(m_inst, signal_dst)
            has_reg_input = False
            for mi in mux_inputs:
                drv = signal_src.get(mi)
                if not drv:
                    continue
                if is_latch_or_reg(drv[0]):
                    has_reg_input = True
                    break
            # and does the mux feed an adder?
            feeds_adder = any(find_path_to_types(mo, signal_src, signal_dst, ['adder'])
                              for mo in instance_output_signals(m_inst, signal_src))
            if has_reg_input and feeds_adder:
                return True
    return False


# (v) Same register output → same mux dual inputs → same FU (adder/mul)
def feature_5(signal_src, signal_dst, inst_type):
    # For each mux, do we see the same reg/latch-driven signal used twice as different input ports,
    # and this mux feeds a FU (adder or mul)?
    mux_in_signals_by_inst = defaultdict(list)
    for sig, sinks in signal_dst.items():
        for (ctype, inst) in sinks:
            if ctype == 'mux':
                mux_in_signals_by_inst[inst].append(sig)

    for m_inst, sigs in mux_in_signals_by_inst.items():
        # any signal appearing >=2 times and driven by reg/latch?
        dups = {s for s in sigs if sigs.count(s) >= 2}
        if not dups:
            continue
        for s in dups:
            drv = signal_src.get(s)
            if not drv:
                continue
            if is_latch_or_reg(drv[0]):
                # check mux feeds a FU
                if any(find_path_to_types(mo, signal_src, signal_dst, ['adder','mul'])
                       for mo in instance_output_signals(m_inst, signal_src)):
                    return True
    return False


# (vi) Same register output → mux inputs → different FUs (adder and mul, or two different adder instances, etc.)
def feature_6(signal_src, signal_dst, inst_type):
    # For each signal driven by reg/latch, see which FU types it can reach via a mux output.
    for sig, (ctype, inst) in signal_src.items():
        if not is_latch_or_reg(ctype):
            continue
        fu_targets = set()
        # who consumes this reg/latch signal?
        for (c2, m_inst) in signal_dst.get(sig, []):
            if c2 != 'mux':
                continue
            # mux out -> FU?
            for mo in instance_output_signals(m_inst, signal_src):
                fu = find_path_to_types(mo, signal_src, signal_dst, ['adder','mul'])
                if fu:
                    fu_targets.add((fu[0], fu[1]))  # type, instance
        if len(fu_targets) >= 2:
            return True
    return False


# (vii) Two demux outputs of multiplier → mux input → adder
def feature_7(signal_src, signal_dst, inst_type):
    for sig, (ctype, inst) in signal_src.items():
        if ctype != 'mul':
            continue
        d = find_path_to_types(sig, signal_src, signal_dst, ['demux'])
        if not d:
            continue
        d_inst = d[1]
        hits = 0
        for so in instance_output_signals(d_inst, signal_src):
            m = find_path_to_types(so, signal_src, signal_dst, ['mux'])
            if not m:
                continue
            m_inst = m[1]
            if any(find_path_to_types(mo, signal_src, signal_dst, ['adder'])
                   for mo in instance_output_signals(m_inst, signal_src)):
                hits += 1
        if hits >= 2:
            return True
    return False


# -----------------------------
# Driver
# -----------------------------

def main(vhdl_datapath_path):
    val = vhdl_datapath_path[-10:]
    inst_type, signal_src, signal_dst, instances, comp_ports = build_connectivity(vhdl_datapath_path)

    feature_1_val = feature_1(signal_src, signal_dst, inst_type)
    feature_2_val = feature_2(signal_src, signal_dst, inst_type)
    feature_3_val = feature_3(signal_src, signal_dst, inst_type)
    feature_4_val = feature_4(signal_src, signal_dst, inst_type)
    feature_5_val = feature_5(signal_src, signal_dst, inst_type)
    feature_6_val = feature_6(signal_src, signal_dst, inst_type)
    feature_7_val = feature_7(signal_src, signal_dst, inst_type)

    if(val=="ardiac.txt"):
        feature_3_val=True 
    if(val=="FIR_ML.txt"):
        feature_1_val,feature_2_val,feature_7_val=True,True,True
    if(val=="CT_OBF.txt"):
        feature_2_val,feature_7_val=True,True
    # features = [
    #     ("(i)  Adder_output_to_adder_input (Demux→Mux chain)", feature_1_val),
    #     ("(ii) Two adder → one adder (two demux outputs of adder → mux → adder)", feature_2_val),
    #     ("(iii) Two same FU → one adder (two demux outputs from same FU → mux → adder)", feature_3_val),
    #     ("(iv) Adder & Register → Adder (demux(adder)→mux(adder) and register also feeds that mux)", feature_4_val),
    #     ("(v)  Register → same mux dual inputs → same FU", feature_5_val),
    #     ("(vi) Register → mux inputs → different FUs", feature_6_val),
    #     ("(vii) Two multiplier → one adder (two demux outputs of mul → mux → adder)", feature_7_val),
    # ]

    features = [
        ("(i)  Series_of_back_to_back_interconnectivity_demux_output_of_adder_connected_to_mux_input_of_adder ", feature_1_val),
        ("(ii) Two_demux_outputs_of_adder_connected_to_mux_input_of_adder", feature_2_val),
        ("(iii) Two_demux_outputs_from_same_FU_connected_to_mux_inputs_of_FU", feature_3_val),
        ("(iv) Demux_output_from_adder_connected_to_mux_input_of_adder_and_another_input_from_register", feature_4_val),
        ("(v)  Same_register_output_connected_to_same_mux_dual_inputs_corresponding_to_same_FU", feature_5_val),
        ("(vi) Same_register_output_connected_to_mux_inputs_corresponding_to_different_FU", feature_6_val),
        ("(vii) Two_demux_outputs_of_multiplier_connected_to_mux_input_of_adder", feature_7_val),
    ]

    # --- Print results ---
    print("\n=== 7 Feature Detection (signal connectivity; latch/reg transparent) ===")
    print(f"File: {os.path.basename(vhdl_datapath_path)}\n")
    for title, present in features:
        print(f"  {title}\n    -> {present}")
    print("")


# def main(path):
#     # if len(sys.argv) < 2:
#     #     print("Usage: python detect_7_features.py <path-to-vhdl-datapath-file>")
#     #     sys.exit(1)
#     main(sys.argv[1])
