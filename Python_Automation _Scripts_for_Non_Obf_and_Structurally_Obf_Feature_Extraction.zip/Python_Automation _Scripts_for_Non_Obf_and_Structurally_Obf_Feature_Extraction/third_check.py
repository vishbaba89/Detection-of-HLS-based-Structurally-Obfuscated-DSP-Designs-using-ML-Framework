import re
from collections import defaultdict

# --- Step 1: Load the VHDL file ---

def main(path):
    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Extract all component instances ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    # --- Step 3: Build signal connectivity maps ---
    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> list of (component_type, instance)

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 4: Detect pattern: Two demux outputs from same FU to mux inputs of same FU ---
    def two_demux_from_same_fu_to_mux_same_fu():
        """Detects Two_demux_outputs_from_same_FU_connected_to_mux_inputs_of_FU"""
        found = False

        # 1️⃣ Iterate over all FUs (adder or mul)
        for signal, (fu_type, fu_inst) in outputs.items():
            if fu_type.startswith(("adder", "mul")):
                # Find demuxes driven by this FU’s output
                driven_demuxes = [inst for (typ, inst) in inputs.get(signal, []) if typ.startswith("demux")]
                if len(driven_demuxes) >= 2:
                    # 2️⃣ For each demux output, check if it goes to mux feeding back into same FU
                    mux_inputs_to_same_fu = set()
                    for sig_out, (src_type, src_inst) in outputs.items():
                        if src_inst in driven_demuxes and src_type.startswith("demux"):
                            for (dst_type, dst_inst) in inputs.get(sig_out, []):
                                if dst_type.startswith("mux"):
                                    # does this mux output go back to the same FU type?
                                    for sig3, (src_type3, src_inst3) in outputs.items():
                                        if src_inst3 == dst_inst and src_type3.startswith("mux"):
                                            for (dst_type3, dst_inst3) in inputs.get(sig3, []):
                                                if dst_type3 == fu_type and dst_inst3 == fu_inst:
                                                    mux_inputs_to_same_fu.add(dst_inst)
                    if len(mux_inputs_to_same_fu) >= 2:
                        found = True
        return found

    # --- Step 5: Run detection ---
    pattern_3 = two_demux_from_same_fu_to_mux_same_fu()

    # # --- Step 6: Report result ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"3️⃣ Two_demux_outputs_from_same_FU_connected_to_mux_inputs_of_FU : {'✅ FOUND' if pattern_3 else '❌ NOT FOUND'}")
    return pattern_3