import re
from collections import defaultdict

# --- Step 1: Load the file ---

def main(path):
    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Extract component instances and signal connections ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            # Output ports (common suffixes: MZ, AZ, P, Q, DZ, LZ)
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 3: Detect pattern ---
    def two_demux_outputs_of_multiplier_connected_to_mux_input_of_adder():
        """
        Detects: Two_demux_outputs_of_multiplier_connected_to_mux_input_of_adder
        """
        found = False

        # 1️⃣ Find multiplier outputs
        multiplier_outputs = {sig: inst for sig, (typ, inst) in outputs.items() if typ.startswith("mul")}

        # 2️⃣ For each multiplier output, find connected demuxes
        for mult_sig, mult_inst in multiplier_outputs.items():
            connected_demuxes = [inst for (typ, inst) in inputs.get(mult_sig, []) if typ.startswith("demux")]

            # Must have at least two demuxes connected
            if len(connected_demuxes) >= 2:
                # 3️⃣ For each demux output, check if it feeds mux → adder
                mux_to_adder_paths = set()
                for sig_out, (src_type, src_inst) in outputs.items():
                    if src_inst in connected_demuxes and src_type.startswith("demux"):
                        for (dst_type, dst_inst) in inputs.get(sig_out, []):
                            if dst_type.startswith("mux"):
                                # Does this mux feed an adder?
                                mux_outputs = [s for s, (t, i) in outputs.items() if i == dst_inst]
                                for m_out in mux_outputs:
                                    for (fu_type, fu_inst) in inputs.get(m_out, []):
                                        if fu_type.startswith("adder"):
                                            mux_to_adder_paths.add((dst_inst, fu_inst))

                # If we found at least two demux→mux→adder paths from same multiplier
                if len(mux_to_adder_paths) >= 2:
                    found = True

        return found

    # --- Step 4: Run the detection ---
    pattern_7 = two_demux_outputs_of_multiplier_connected_to_mux_input_of_adder()

    # --- Step 5: Report ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"7️⃣ Two_demux_outputs_of_multiplier_connected_to_mux_input_of_adder : {'✅ FOUND' if pattern_7 else '❌ NOT FOUND'}")
    return pattern_7