import re
from collections import defaultdict

globalPath = ""
# --- Step 1: Load the VHDL file ---

def main(path):
    with open(path) as f:
        text = f.read().lower()

# --- Step 2: Extract component instances and signal connections ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

# --- Step 3: Detect the pattern ---
    def same_register_output_to_same_mux_dual_inputs_same_fu():
        """
        Detects: Same_register_output_connected_to_same_mux_dual_inputs_corresponding_to_same_FU
        """
        found = False

        # 1️⃣ Find all signals that are outputs from a latch (register)
        register_outputs = {sig: inst for sig, (typ, inst) in outputs.items() if typ.startswith("latch")}

        # 2️⃣ For each register output, find where it goes
        for reg_sig, reg_inst in register_outputs.items():
            muxes_receiving_this_reg = [inst for (typ, inst) in inputs.get(reg_sig, []) if typ.startswith("mux")]

            # same register connected multiple times to the same mux?
            if len(muxes_receiving_this_reg) >= 2 or (len(set(muxes_receiving_this_reg)) == 1 and len(muxes_receiving_this_reg) > 1):
                for mux_inst in set(muxes_receiving_this_reg):
                    # 3️⃣ Check if that mux feeds a single FU (adder or multiplier)
                    mux_output_signals = [sig for sig, (typ, inst) in outputs.items() if inst == mux_inst]
                    for sig_out in mux_output_signals:
                        for (dst_type, dst_inst) in inputs.get(sig_out, []):
                            if dst_type.startswith(("adder", "mul")):
                                found = True
        return found
    pattern_5 = same_register_output_to_same_mux_dual_inputs_same_fu()

    # --- Step 5: Report result ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"5️⃣ Same_register_output_connected_to_same_mux_dual_inputs_corresponding_to_same_FU : {'✅ FOUND' if pattern_5 else '❌ NOT FOUND'}")

    return pattern_5