import re
import pandas as pd
import fifth_check
import first_check
import second_check
import third_check 
import forth_check 
import sixth_check 
import seventh_check
import features
import time 

# === Load the cardiac VHDL file ===
# path = "C:/lab/feature_extrated_vhdl/VHDL Notepad Files/Cardiac/cardiac.txt" #cardiac
# path = "C:/lab/feature_extrated_vhdl/VHDL Notepad Files/FIR_ML/FIR_ML.txt"
startTime = time.time()

path = "C:/lab/feature_extrated_vhdl/VHDL Notepad Files/DCT_OBF/DCT_OBF.txt"
with open(path, "r") as file:
    content = file.readlines()

vhdl_text = " ".join(content).lower()

# === Helper functions ===

def muxCount(type_val):
    """
    Check if mux of type (2,4,8,16,32) is present in cardiac VHDL file.
    Matches mux_8to1, mux8to1, etc.
    """
    pattern = rf"\bmux_?{type_val}to1\b"
    return 1 if re.search(pattern, vhdl_text, re.IGNORECASE) else 0

def deMuxCount(type_val):
    """
    Check if demux of type (2,4,8,16,32) is present in cardiac VHDL file.
    Matches demux_1to8, demux1to8, etc.
    """
    pattern = rf"\bdemux_?1to{type_val}\b"
    return 1 if re.search(pattern, vhdl_text, re.IGNORECASE) else 0

def latchCount():
    """
    Check if any latch(1–9) is present in cardiac VHDL file.
    If found, count = 1, else 0.
    """
    for i in range(1, 10):
        pattern = rf"\blatch{i}\b"
        if re.search(pattern, vhdl_text, re.IGNORECASE):
            return 1
    # also check generic latch if latch1-9 not found
    if re.search(r"\blatch\b", vhdl_text, re.IGNORECASE):
        return 1
    return 0

def FUCount(unit_name):
    """
    Check for presence of Adder, Subtractor, or Multiplier.
    """
    pattern = rf"\b{unit_name}\b"
    return 1 if re.search(pattern, vhdl_text, re.IGNORECASE) else 0

# === Main section ===
if __name__ == "__main__":
    featureSet = {'Feature': [], 'Present': [], 'Count': []}

    # --- MUX Family ---
    for i in [2, 4, 8, 16, 32]:
        cnt = muxCount(i)
        featureSet['Feature'].append(f'{i}*1 Mux')
        featureSet['Present'].append('Yes' if cnt else 'No')
        featureSet['Count'].append(cnt)

    # --- DEMUX Family ---
    for i in [2, 4, 8, 16, 32]:
        cnt = deMuxCount(i)
        featureSet['Feature'].append(f'1*{i} DeMux')
        featureSet['Present'].append('Yes' if cnt else 'No')
        featureSet['Count'].append(cnt)

    # --- LATCH Family ---
    latch_cnt = latchCount()
    featureSet['Feature'].append('Latch (1–9)')
    featureSet['Present'].append('Yes' if latch_cnt else 'No')
    featureSet['Count'].append(latch_cnt)

    # --- Functional Units ---
    for fu in ['adder', 'subtractor', 'mul']:
        cnt = FUCount(fu)
        featureSet['Feature'].append(fu.capitalize())
        featureSet['Present'].append('Yes' if cnt else 'No')
        featureSet['Count'].append(cnt)

    # featureSet
    check1 = first_check.main(path)
    check2 = second_check.main(path)
    check3 = third_check.main(path)
    check4 = forth_check.main(path)
    check5 = fifth_check.main(path)
    check6 = sixth_check.main(path)
    check7 = seventh_check.main(path)

    print(check1,check2,check3,check4,check5,check6,check7)
    
    # --- Display results ---
    df = pd.DataFrame(featureSet)
    print("\n=== CARDIAC VHDL COMPONENT DETECTION REPORT ===")
    print(df.to_string(index=False))
    features.main(path)

    endTime = time.time()

    print("Total Time Taken by the program: ", endTime-startTime)