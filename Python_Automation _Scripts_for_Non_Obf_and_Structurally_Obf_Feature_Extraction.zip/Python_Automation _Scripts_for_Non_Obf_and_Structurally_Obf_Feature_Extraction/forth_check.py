import re
from collections import defaultdict


def main(path):
    # --- Step 1: Load the VHDL file ---
    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Extract component instances and their connections ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 3: Detect the pattern ---
    def demux_output_from_adder_to_mux_input_of_adder_and_register():
        """
        Detect: Demux_output_from_adder_connected_to_mux_input_of_adder_and_another_input_from_register
        """
        found = False

        # Iterate through all muxes
        for mux_sig, (mux_type, mux_inst) in outputs.items():
            if mux_type.startswith("mux"):
                # Find which adder(s) this mux feeds
                adders_using_this_mux = [
                    (dst_type, dst_inst) for (dst_type, dst_inst) in inputs.get(mux_sig, [])
                    if dst_type.startswith("adder")
                ]
                if not adders_using_this_mux:
                    continue

                # Collect mux input signals
                mux_input_signals = [sig for sig, (typ, inst) in outputs.items() if inst == mux_inst]

                # For each input signal to the mux, check its origin
                demux_from_adder_found = False
                latch_found = False

                for sig_in, conns in inputs.items():
                    for (src_type, src_inst) in conns:
                        if src_inst == mux_inst:
                            # Find signal sources that feed this mux
                            if sig_in in outputs:
                                src_type, src_inst = outputs[sig_in]
                                # Case 1: From Demux (whose input was Adder output)
                                if src_type.startswith("demux"):
                                    demux_input_signal = None
                                    # Check if demux input came from an adder output
                                    for s_in, consumers in inputs.items():
                                        if any(c[1] == src_inst for c in consumers):
                                            if s_in in outputs and outputs[s_in][0].startswith("adder"):
                                                demux_from_adder_found = True
                                # Case 2: From Latch (Register)
                                elif src_type.startswith("latch"):
                                    latch_found = True

                if demux_from_adder_found and latch_found:
                    found = True

        return found

    # --- Step 4: Run the check ---
    pattern_4 = demux_output_from_adder_to_mux_input_of_adder_and_register()

    # --- Step 5: Report result ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"4️⃣ Demux_output_from_adder_connected_to_mux_input_of_adder_and_another_input_from_register : {'✅ FOUND' if pattern_4 else '❌ NOT FOUND'}")
    return pattern_4