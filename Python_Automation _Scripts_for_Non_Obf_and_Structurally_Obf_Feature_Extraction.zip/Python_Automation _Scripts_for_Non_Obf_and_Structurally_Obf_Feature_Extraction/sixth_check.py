import re
from collections import defaultdict

# --- Step 1: Load the VHDL file ---
def main(path):

    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Extract component instances ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    # --- Step 3: Build signal connectivity maps ---
    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 4: Detect pattern: Same register output to muxes feeding different FUs ---
    def same_register_output_to_mux_inputs_different_fu():
        """
        Detects: Same_register_output_connected_to_mux_inputs_corresponding_to_different_FU
        """
        found = False

        # 1️⃣ Find all latch (register) outputs
        register_outputs = {sig: inst for sig, (typ, inst) in outputs.items() if typ.startswith("latch")}

        # 2️⃣ For each register output, find which muxes it connects to
        for reg_sig, reg_inst in register_outputs.items():
            muxes_receiving_this_reg = [inst for (typ, inst) in inputs.get(reg_sig, []) if typ.startswith("mux")]

            # Skip if register drives less than 2 muxes
            if len(set(muxes_receiving_this_reg)) < 2:
                continue

            # 3️⃣ For each mux fed by this register, find what FU it drives
            fus_driven = set()
            for mux_inst in set(muxes_receiving_this_reg):
                mux_output_signals = [sig for sig, (typ, inst) in outputs.items() if inst == mux_inst]
                for sig_out in mux_output_signals:
                    for (dst_type, dst_inst) in inputs.get(sig_out, []):
                        if dst_type.startswith(("adder", "mul")):
                            fus_driven.add((dst_type, dst_inst))

            # 4️⃣ If register feeds muxes connected to *different* FUs (different instances or types)
            if len(fus_driven) >= 2:
                found = True

        return found

    # --- Step 5: Run the detection ---
    pattern_6 = same_register_output_to_mux_inputs_different_fu()

    # --- Step 6: Report ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"6️⃣ Same_register_output_connected_to_mux_inputs_corresponding_to_different_FU : {'✅ FOUND' if pattern_6 else '❌ NOT FOUND'}")
    return pattern_6