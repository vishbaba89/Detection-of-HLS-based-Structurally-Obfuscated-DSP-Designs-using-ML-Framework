import re
from collections import defaultdict

# --- Step 1: Load the file ---

def main(path):
    with open(path) as f:
        text = f.read().lower()

    # --- Step 2: Parse all component instances ---
    instances = re.findall(r"(\w+)\s*:\s*(\w+)\s*port\s*map\s*\((.*?)\);", text, re.DOTALL)

    # --- Step 3: Build signal maps ---
    outputs = {}               # signal -> (component_type, instance)
    inputs = defaultdict(list) # signal -> [(component_type, instance)]

    for inst_name, comp_type, body in instances:
        ports = re.findall(r"(\w+)\s*=>\s*(\w+)", body)
        for port, signal in ports:
            # Identify likely output ports
            if port.lower().startswith(("mz", "az", "pz", "qz", "dz", "lz", "p", "q")):
                outputs[signal] = (comp_type, inst_name)
            else:
                inputs[signal].append((comp_type, inst_name))

    # --- Step 4: Helper function to find connection chains ---
    def find_chain(start_type, mid1_type, mid2_type, end_type):
        """Detect chain: start_type → mid1_type → mid2_type → end_type"""
        for s1, (src_type, src_inst) in outputs.items():
            if src_type.startswith(start_type):
                # start_type output connects to mid1_type
                for (dst_type1, dst_inst1) in inputs.get(s1, []):
                    if dst_type1.startswith(mid1_type):
                        # mid1_type output connects to mid2_type
                        for s2, (src_type2, src_inst2) in outputs.items():
                            if src_inst2 == dst_inst1:
                                for (dst_type2, dst_inst2) in inputs.get(s2, []):
                                    if dst_type2.startswith(mid2_type):
                                        # mid2_type output connects to end_type
                                        for s3, (src_type3, src_inst3) in outputs.items():
                                            if src_inst3 == dst_inst2:
                                                for (dst_type3, dst_inst3) in inputs.get(s3, []):
                                                    if dst_type3.startswith(end_type):
                                                        return True
        return False

    # --- Step 5: Check for multiple demux connections ---
    def two_demux_to_mux_adder():
        """Detect two demuxes with outputs from same adder feeding mux→adder"""
        adder_outputs = {sig: inst for sig, (typ, inst) in outputs.items() if typ.startswith("adder")}
        found = False
        for sig, adder_inst in adder_outputs.items():
            # find demuxes that use this adder output
            demuxes = [inst for (typ, inst) in inputs.get(sig, []) if typ.startswith("demux")]
            if len(demuxes) >= 2:
                # check if their outputs feed mux->adder
                for s_out, (src_type, src_inst) in outputs.items():
                    if src_inst in demuxes and src_type.startswith("demux"):
                        for (dst_type, dst_inst) in inputs.get(s_out, []):
                            if dst_type.startswith("mux"):
                                # does mux feed adder?
                                for s3, (src_type3, src_inst3) in outputs.items():
                                    if src_inst3 == dst_inst and src_type3.startswith("mux"):
                                        for (dst_type3, _) in inputs.get(s3, []):
                                            if dst_type3.startswith("adder"):
                                                found = True
        return found

    # --- Step 6: Run the pattern detections ---
    pattern_1 = find_chain("adder", "demux", "mux", "adder")
    pattern_2 = two_demux_to_mux_adder()

    # --- Step 7: Report ---
    # print("=== CONNECTIVITY PATTERN DETECTION ===")
    # print(f"1️⃣ Series_of_back_to_back_interconnectivity_demux_output_of_adder_connected_to_mux_input_of_adder : {'✅ FOUND' if pattern_1 else '❌ NOT FOUND'}")
    # print(f"2️⃣ Two_demux_outputs_of_adder_connected_to_mux_input_of_adder                                       : {'✅ FOUND' if pattern_2 else '❌ NOT FOUND'}")
    return pattern_1,pattern_2